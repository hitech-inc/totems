<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Add new clip form</title>
</head>
<body>
		<h1>Добавлено новое видео</h1>
		<p>Имя видео: <strong>{{ $clipName }}</strong></p>
		<p>Подробнее ->: <a href="http://totems.loc/" target="_blank">www.totems.loc</a></p>
</body>
</html>	