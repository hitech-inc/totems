<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Clip deleted form</title>
</head>
<body>
	<h1>Удален видео - файл</h1>
	<p>Имя файла: <strong><?php echo e($clipName); ?></strong></p>	
	<p>Подробнее ->: <a href="http://totems.loc/" target="_blank">www.totems.loc</a></p>
</body>
</html>