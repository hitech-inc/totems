<table class="table table-responsive" id="clips-table">
    <thead>
        <tr>
            <th>Name</th>
        <th>Path</th>
            <th colspan="3">Action</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $clips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo $clip->name; ?></td>
            <td><?php echo $clip->path; ?></td>
            <td>
                <?php echo Form::open(['route' => ['clips.destroy', $clip->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo route('clips.show', [$clip->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                    <a href="<?php echo route('clips.edit', [$clip->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>