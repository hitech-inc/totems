<table class="table table-responsive" id="totems-table">
    <thead>
        <tr>
            <th>Name</th>
            <th>Status</th>
            <th>Ip Addr</th>
            <th>Last Seen At</th>
            <th colspan="3">Action</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $totems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $totem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo $totem->name; ?></td>
            <td>
                <span class="<?php echo e($totem->status); ?>"><?php echo $totem->status; ?></span>
            </td>
            <td><?php echo $totem->ip_addr; ?></td>
            <td>
                <?php if(!is_null($totem->last_seen_at)): ?>
                    <?php echo $totem->last_seen_at->diffForHumans(); ?>

                <?php endif; ?>
            </td>
            <td>
                <?php echo Form::open(['route' => ['totems.destroy', $totem->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo route('totems.show', [$totem->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                    <a href="<?php echo route('totems.edit', [$totem->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>